# {-_-}

Ce répertoire est le correcteur automatique des exams ; pour l'utiliser, il est nécessaire de :
* installer [nodejs](https://nodejs.org/)
* installer les dépendances : pour cela, dans un terminal, se positionner dans le même répertoire que ce README puis saisir `npm install`
* ajouter dans le répertoire `/public` les fichiers `.html` à valider
* lancer le correcteur avec `npm start`
